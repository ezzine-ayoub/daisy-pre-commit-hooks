#!/usr/bin/env python3
import sys
import os
import argparse

DEFAULT_IGNORE_DIRS = ['.idea', '__pycache__', '.vscode', '.git']

parser = argparse.ArgumentParser(description="Check XML filenames for required prefixes in Odoo modules")

parser.add_argument('--PREFIXES', required=True, help='Comma-separated list of required prefixes (e.g. dc_,inheret_)')
parser.add_argument('--IGNORE_PREFIXES', help='Comma-separated list of filename prefixes to ignore (e.g. test_,temp_)')
parser.add_argument('--IGNORE_DIRECTORIES', help='Comma-separated list of directories to ignore')
parser.add_argument('--DIRECTORIES', help='Comma-separated list of directories to scan (default is all)')

parser.add_argument('filenames', nargs='*', help='Files passed by pre-commit (not used in this script)')

args = parser.parse_args()

class XMLFileScanner:
    def __init__(self):
        self.allowed_prefixes = []
        self.ignore_prefixes = []
        self.ignore_dirs = list(DEFAULT_IGNORE_DIRS)
        self.target_dirs = []
        self.invalid_files = []  # List of tuples: (path, reason)

    def load_environment(self):
        self.allowed_prefixes = args.PREFIXES.split(",")
        self.ignore_prefixes = args.IGNORE_PREFIXES.split(",") if args.IGNORE_PREFIXES else []
        if args.IGNORE_DIRECTORIES:
            self.ignore_dirs.extend(args.IGNORE_DIRECTORIES.split(","))
        self.target_dirs = args.DIRECTORIES.split(",") if args.DIRECTORIES else [os.getcwd()]

    def scan_files(self):
        for base_dir in self.target_dirs:
            base_dir = os.path.abspath(base_dir)
            for dirpath, dirnames, filenames in os.walk(base_dir):
                dirnames[:] = [d for d in dirnames if d not in self.ignore_dirs]

                for file in filenames:
                    if not file.endswith(".xml"):
                        continue

                    rel_path = os.path.relpath(os.path.join(dirpath, file), base_dir)

                    # Skip if it starts with an ignored prefix
                    if any(file.startswith(ignored) for ignored in self.ignore_prefixes):
                        reason = f"Commence par un préfixe ignoré: {next(p for p in self.ignore_prefixes if file.startswith(p))}"
                        self.invalid_files.append((rel_path, reason))
                        continue

                    # Check required prefixes
                    if not any(file.startswith(prefix) for prefix in self.allowed_prefixes):
                        reason = f"Ne commence pas par un des préfixes requis: {', '.join(self.allowed_prefixes)}"
                        self.invalid_files.append((rel_path, reason))

    def display_invalid_files(self):
        if self.invalid_files:
            print("❌ Des fichiers XML non conformes ont été détectés :\n")
            for path, reason in self.invalid_files:
                print(f" - {path} ➤ {reason}")
            print("\nCorrigez les noms de fichiers pour respecter les préfixes requis.")
            sys.exit(1)

    def run(self):
        sys.stdout.reconfigure(encoding='utf-8')
        self.load_environment()
        self.scan_files()
        self.display_invalid_files()
        sys.exit(0)

def main():
    scanner = XMLFileScanner()
    scanner.run()

if __name__ == "__main__":
    main()
